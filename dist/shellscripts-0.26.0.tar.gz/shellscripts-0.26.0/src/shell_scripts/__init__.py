__version__ = "0.26.0"

from .core import main  # noqa: F401

__all__ = ["__version__", "main"]
